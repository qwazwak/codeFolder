//By Rustan Hoffman



public class Cat extends Animal {
	public void meow() {
		System.out.println("moew");
	}
}
