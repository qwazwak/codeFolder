//By Rustan Hoffman



public class Animal {
	public int life;
	public Animal(){
		this.life = 100;
	}
	
	public void kill() {
		this.life = 0;
	}
}
