//By Rustan Hoffman



public class Fish extends Animal {
	public void makeFishSound() {
		System.out.println("'    '");
	}

}
