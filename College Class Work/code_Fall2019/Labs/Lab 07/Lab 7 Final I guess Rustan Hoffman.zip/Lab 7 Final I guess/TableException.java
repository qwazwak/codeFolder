
public class TableException extends RuntimeException {
	public TableException(String s) {
		super(s);
	}
}
