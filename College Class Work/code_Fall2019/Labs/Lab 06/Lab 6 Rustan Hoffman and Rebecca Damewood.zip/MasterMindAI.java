//Lab 06, Mastermind, by Rustan Hoffman and Rebecca Damewood

public interface MasterMindAI {
	public Guess nextGuess(int guess_id);
}
