// 
// Decompiled by Procyon v0.5.36
// 

public class FileIOException extends RuntimeException
{
    /**
	 * added this
	 */
	private static final long serialVersionUID = -6971647425962006652L;

	public FileIOException(final String message) {
        super(message);
    }
}