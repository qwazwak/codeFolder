package matrix;

public class MatrixException extends RuntimeException
{
   /**
	 * added
	 */
	private static final long serialVersionUID = -955711242158768633L;

public MatrixException(String s)
   {
      super(s);
   }
}