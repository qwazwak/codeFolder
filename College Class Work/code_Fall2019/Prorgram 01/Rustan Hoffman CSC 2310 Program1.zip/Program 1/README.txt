Rustan Hoffman

Setup is more or less the same as the 'P1_Compile&Run.pdf'
Boshart's java.7z is required from https://mboshart.dyndns.org/~mboshart/2310Labs/Lab01/Java.7z
Extract java.7z to the root of C:\

Go back to the project folder
To build run the command 'build.bat c'
	note: if the previously mentioned java folder was extracted to another drive, use that drives letter instead of C
To run the program after building, run the command 'run.bat'
	if you wish to give the program inputs from a text file, edit run.bat
	
	WARNING: do not use the same command window for both build and run.
		  after building, close that window and open a new one.
		   as to why: your guess is probably better than mine